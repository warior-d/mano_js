##
# All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.
##

import asyncio
import asyncssh
# import requests
import logging
import os

from osm_ee.exceptions import VnfException

import osm_ee.util.util_ee as util_ee
#import osm_ee.util.util_ansible as util_ansible
#import osm_ee.vnf.mylib as mylib


from netmiko import ConnectHandler
from netmiko.ssh_exception import NetMikoTimeoutException
from netmiko.ssh_exception import AuthenticationException
from paramiko.ssh_exception import SSHException

import json
from time import sleep

class VnfEE:
    
    PLAYBOOK_PATH = "/app/EE/osm_ee/vnf"
    SSH_SCRIPT = "/app/EE/osm_ee/vnf/run_ssh.sh"

    def __init__(self, config_params):
        self.logger = logging.getLogger('osm_ee.vnf')
        self.config_params = config_params

    def get_vyos_connect(self):
    
        try: 
            if self.net_connect.is_alive():
                return self.net_connect
   
        except (NameError,AttributeError):
            pass
        finally:
            vyos_router = {
              "device_type": "vyos",
              "host": self.config_params["ssh-hostname"],
              "username": self.config_params["ssh-username"],
              # "password": self.model.config["ssh-password"],
              "use_keys": True,
              "key_file":"/root/.ssh/id_rsa",
              "port": 22,
            }

            return ConnectHandler(**vyos_router)
        
    def verify_credentials(self):
        retry=10
        while retry>0:
            try:   
                self.logger.info(f"Waiting for SSH connection {retry}!")
                net_connect = self.get_vyos_connect()
            
            except (NetMikoTimeoutException) as ex:
                retry-=1
                self.logger.debug(ex)                
                sleep(3)
          
            except AuthenticationException as ex:
                self.logger.debug(ex)
                return (False, str(ex))
            
            except Exception as ex:
                return (False, str(ex))
                
            else:
                return (True,"")
        
        return (False,"Can't connect to remote...")
    
    # config method saves SSH access parameters (host and username) for future use by other methods.
    # It is mandatory in any case.
    async def config(self, id, params):
        self.logger.debug("Execute action config, params: {}".format(params))
        # Config action is special, params are merged with previous config calls
        self.config_params.update(params)
        required_params = ["ssh-hostname"]
        self._check_required_params(self.config_params, required_params)
        
        verified, output = self.verify_credentials()
        if verified:
            yield "OK", "Configured & SSH Verified"
        else:
            yield "ERROR", "Invalid SSH credentials"+"\n"+output
        
        
    
    
    async def ssh_exec(self, host: str, user: str, command: str) -> (int, str):
        """
            Execute a remote command via SSH.
        """

        try:
            async with asyncssh.connect(host, username=user, known_hosts=None) as conn:
                self.logger.debug("Executing command '{}'".format(command))
                result = await conn.run(command)
                self.logger.debug("Result: {}".format(result))
                return result.exit_status, result.stdout+result.stderr
        except Exception as e:
            self.logger.error("Error: {}".format(repr(e)))
            return -1, str(e)

    async def add_port_forwarding(self, id, params):
        self._check_required_params(params, ["dst_port","trans_addr","trans_port"])

        try:
            config = [ "delete nat destination rule 100",
                      f"set nat destination rule 100 destination port '{params['dst_port']}'",
                       "set nat destination rule 100 inbound-interface 'eth0'",
                       "set nat destination rule 100 protocol 'tcp'",
                      f"set nat destination rule 100 translation address '{params['trans_addr']}'",
                      f"set nat destination rule 100 translation port '{params['trans_port']}'"]

            net_connect = self.get_vyos_connect()
            output= net_connect.send_config_set(config, exit_config_mode=False)

            # commit configuration
            output+="\n\n"+net_connect.commit()
            
            yield "OK", output
            
        except Exception as ex:
            yield "ERROR", str(ex)
            
            
    async def del_port_forwarding(self,  id, params):
        # self._check_required_params(params, ["prefix"])
                    
        try:
            config = [f"delete nat destination rule 100"]

            net_connect = self.get_vyos_connect()
            output= net_connect.send_config_set(config, exit_config_mode=False)

            # commit configuration
            output+="\n\n"+net_connect.commit()
            
            yield "OK", output
            
        except Exception as ex:
            yield "ERROR", str(ex)  

    async def get_port_forwarding(self, id, params):

        dst_port=None
        trans_addr=None
        trans_port=None
        
        try:
            net_connect = self.get_vyos_connect()
            output = net_connect.send_command('sh configuration commands | match "nat destination"')
            self.logger.debug(output)
            
            for line in output.split("\n"):
                if "destination port" in line:
                    dst_port=line.split(" ")[7].strip("'")
                if "translation address" in line:
                    trans_addr=line.split(" ")[7].strip("'")
                if "translation port" in line:
                    trans_port=line.split(" ")[7].strip("'")
                    
        except Exception as ex:
            yield "ERROR", str(ex)

        yield "OK", json.dumps({"dst_port":dst_port, "trans_addr":trans_addr, "trans_port":trans_port})

    async def add_acl(self, id, params):
        self._check_required_params(params, ["src_addr","dst_addr","proto"])

        try:
            config = [ "delete firewall name eaas rule 100",
                      f"set firewall name eaas rule 100 source address '{params['src_addr']}'",
                      f"set firewall name eaas rule 100 destination address '{params['dst_addr']}'",
                      f"set firewall name eaas rule 100 protocol {params['proto']}",                      
                       "set firewall name eaas rule 100 action drop"]
            if "src_port" in params and params['src_port']!="":
                config.append(f"set firewall name eaas rule 100 source port '{params['src_port']}'");
            if "dst_port" in params and params['dst_port']!="":
                config.append(f"set firewall name eaas rule 100 destination port '{params['dst_port']}'");

            net_connect = self.get_vyos_connect()
            output= net_connect.send_config_set(config, exit_config_mode=False)

            # commit configuration
            output+="\n\n"+net_connect.commit()
            
            yield "OK", output
            
        except Exception as ex:
            yield "ERROR", str(ex)
            
            
    async def del_acl(self,  id, params):
        # self._check_required_params(params, ["prefix"])
                    
        try:
            config = [f"delete firewall name eaas rule 100"]

            net_connect = self.get_vyos_connect()
            output= net_connect.send_config_set(config, exit_config_mode=False)

            # commit configuration
            output+="\n\n"+net_connect.commit()
            
            yield "OK", output
            
        except Exception as ex:
            yield "ERROR", str(ex)  

    async def get_acl(self, id, params):
        """
        set firewall name eaas rule 100 destination address '87.250.250.242'
        set firewall name eaas rule 100 destination port '80'
        set firewall name eaas rule 100 protocol 'tcp'
        set firewall name eaas rule 100 source address '0.0.0.0/0'
        set firewall name eaas rule 100 source port '33'
        """
        
        ret={"src_addr":None, "dst_addr":None, "proto":None, "src_port":None, "dst_port": None}
        
        try:
            net_connect = self.get_vyos_connect()
            output = net_connect.send_command('sh configuration commands | match "firewall name eaas rule 100"')
            self.logger.debug(output)
            
            for line in output.split("\n"):
                if "destination address" in line:
                    ret["dst_addr"]=line.split(" ")[8].strip("'")
                if "destination port" in line:
                    ret["dst_port"]=line.split(" ")[8].strip("'")
                if "source address" in line:
                    ret["src_addr"]=line.split(" ")[8].strip("'")
                if "source port" in line:
                    ret["src_port"]=line.split(" ")[8].strip("'")
                if "protocol" in line:
                    ret["proto"]=line.split(" ")[7].strip("'")
                    
        except Exception as ex:
            yield "ERROR", str(ex)

        yield "OK", json.dumps(ret)
        
    async def run(self, id, params):
        self.logger.debug("Execute action run, params: '{}'".format(params))

        self._check_required_params(params, ["cmd"])
        # command = "touch" + " " + params["file"]
        # return_code, description = await self.ssh_exec(self.config_params["ssh-hostname"], self.config_params["ssh-username"], params["cmd"])

        output=""
        try:
            net_connect = self.get_vyos_connect()
            output+= net_connect.send_command(params["cmd"])

        except Exception as ex:
            yield "ERROR", str(ex)
        
        yield "OK", output

    async def shell_exec(self, id, params):
        self.logger.debug("Execute action cmd, params: '{}'".format(params))

        self._check_required_params(params, ["cmd"])
        
        return_code, description = await self.ssh_exec(self.config_params["ssh-hostname"], self.config_params["ssh-username"], params["cmd"])
        if return_code != 0:
            yield "ERROR", description
        else:
            yield "OK", description

    
    # Static method that verifies whether a parameter exists in the map
    @staticmethod
    def _check_required_params(params, required_params):
        for required_param in required_params:
            if required_param not in params:
                raise VnfException("Missing required param: {}".format(required_param))
